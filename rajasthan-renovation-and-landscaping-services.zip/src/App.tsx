import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { WhyChooseUs } from './components/WhyChooseUs';
import { Gallery } from './components/Gallery';
import { About } from './components/About';
import { QuoteSection } from './components/QuoteSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { MobileStickyBar } from './components/MobileStickyBar';

export default function App() {
  const [selectedServiceForQuote, setSelectedServiceForQuote] = useState<string>('');

  const handleSelectService = (serviceTitle: string) => {
    setSelectedServiceForQuote(serviceTitle);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf8f5] text-[#22252a] font-sans antialiased pb-16 sm:pb-0">
      {/* Sticky Navigation */}
      <Navbar />

      {/* Main Content Flow */}
      <main className="flex-1">
        <Hero />
        <Services onSelectServiceForEnquiry={handleSelectService} />
        <WhyChooseUs />
        <Gallery />
        <About />
        <QuoteSection preselectedService={selectedServiceForQuote} />
        <ContactSection />
      </main>

      {/* Quiet Structured Footer */}
      <Footer />

      {/* Mobile Sticky Bar (<15% viewport height) */}
      <MobileStickyBar />
    </div>
  );
}
