/**
 * Centralized business configuration for Rajasthan Renovation and Landscaping Services.
 *
 * Rules:
 * - Unknown values stay null; never print null or raw placeholder text on the live site.
 * - Single point of truth for business contact details, services, and content.
 * - Khushkaran is the sole primary contact person.
 * - Only verified phone number: 0484914973.
 */

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  category: 'lawn' | 'design' | 'trees' | 'tilling' | 'fencing' | 'renovation';
  tag: string;
}

export interface GalleryProject {
  id: string;
  title: string;
  category: 'lawn' | 'design' | 'trees' | 'tilling' | 'fencing' | 'renovation';
  categoryLabel: string;
  description: string;
  aspectRatio: string;
  isRepresentative: boolean;
}

export interface BusinessConfig {
  name: string;
  shortName: string;
  tagline: string;
  contactName: string;
  phoneDisplay: string;
  phoneInternational: string | null;
  phoneTelLink: string;
  address: string | null;
  serviceArea: string | null;
  email: string | null;
  logoUrl: string | null;
  heroImageUrl: string | null;
  galleryImages: GalleryProject[];
  quoteFormEndpoint: string | null;
  socialLinks: string[];
  openingHours: string | null;
}

export const business: BusinessConfig = {
  name: "Rajasthan Renovation and Landscaping Services",
  shortName: "Rajasthan Landscaping",
  tagline: "Transform Your Outdoor Space",
  contactName: "Khushkaran",
  phoneDisplay: "0484914973",
  phoneInternational: null,
  phoneTelLink: "tel:0484914973",
  address: null,
  serviceArea: null,
  email: null,
  logoUrl: null,
  heroImageUrl: null,
  galleryImages: [],
  quoteFormEndpoint: null,
  socialLinks: [],
  openingHours: null,
};

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "lawn-mowing-trimming",
    number: "01",
    title: "Lawn Mowing & Trimming",
    shortDesc: "Lawn maintenance and trimming to help keep outdoor spaces neat.",
    fullDesc: "Regular lawn care, precision edge trimming, and turf upkeep designed to maintain clean lines and healthy outdoor grassed areas.",
    features: [
      "Precision perimeter edging",
      "Regular or one-off mowing",
      "Clipping cleanup and pathway sweeping"
    ],
    category: "lawn",
    tag: "Lawn Maintenance"
  },
  {
    id: "landscape-design",
    number: "02",
    title: "Landscape Design",
    shortDesc: "Landscaping ideas and outdoor layouts suited to the project.",
    fullDesc: "Thoughtful outdoor transformations incorporating garden layouts, natural turf, pavers, mulch beds, and practical outdoor features tailored to your yard.",
    features: [
      "Outdoor layout planning",
      "Garden bed creation and mulch placement",
      "Practical spatial organization"
    ],
    category: "design",
    tag: "Outdoor Design"
  },
  {
    id: "tree-shrub-removal",
    number: "03",
    title: "Tree & Shrub Removal",
    shortDesc: "Tree and shrub removal services, subject to project requirements and applicable regulations.",
    fullDesc: "Safe removal of unwanted small trees, overgrown shrubs, hedges, and vegetative clutter to open up space and prepare your property.",
    features: [
      "Overgrown shrub pruning and clearing",
      "Controlled vegetative branch removal",
      "Debris removal and site clearance"
    ],
    category: "trees",
    tag: "Site Clearing"
  },
  {
    id: "tilling",
    number: "04",
    title: "Tilling & Ground Preparation",
    shortDesc: "Ground preparation and tilling for suitable landscaping projects.",
    fullDesc: "Mechanical soil aeration, breaking up hardened earth, and leveling ground for fresh turf, garden beds, or new outdoor installations.",
    features: [
      "Rotary soil loosening and turning",
      "Pre-turf and pre-planting ground prep",
      "Leveling and grading assistance"
    ],
    category: "tilling",
    tag: "Groundwork"
  },
  {
    id: "fencing",
    number: "05",
    title: "Fencing Services",
    shortDesc: "Fencing services for outdoor spaces and property boundaries.",
    fullDesc: "Installation and repair of boundary fences, privacy screens, and garden barriers to enhance property security and clean boundary lines.",
    features: [
      "Boundary fence alignment",
      "Timber, colorbond, or modular fencing options",
      "Gate fitting and post anchoring"
    ],
    category: "fencing",
    tag: "Boundary Structures"
  },
  {
    id: "renovation-services",
    number: "06",
    title: "Renovation Services",
    shortDesc: "A section for confirmed renovation work.",
    fullDesc: "Practical outdoor and property renovation-related improvements. Specific renovation categories and structural work are confirmed directly based on project scope.",
    features: [
      "Outdoor surface restoration",
      "Path and border structural renewal",
      "Scope confirmed upon project review"
    ],
    category: "renovation",
    tag: "Renovation Scope"
  }
];

export const REPRESENTATIVE_GALLERY: GalleryProject[] = [
  {
    id: "project-1",
    title: "Manicured Turf & Edge Trimming",
    category: "lawn",
    categoryLabel: "Lawn Mowing & Care",
    description: "Even turf mowing with clean boundary edging along concrete paths and garden beds.",
    aspectRatio: "4:3",
    isRepresentative: true
  },
  {
    id: "project-2",
    title: "Integrated Garden & Paving Layout",
    category: "design",
    categoryLabel: "Landscape Design",
    description: "Thoughtful residential garden scheme with structured stepping pavers, stone borders, and dark organic mulch.",
    aspectRatio: "16:9",
    isRepresentative: true
  },
  {
    id: "project-3",
    title: "Shrub Clearance & Garden Reclaim",
    category: "trees",
    categoryLabel: "Tree & Shrub Removal",
    description: "Clearing dense root zones and overgrown hedges to reclaim sunlight and usable ground space.",
    aspectRatio: "4:3",
    isRepresentative: true
  },
  {
    id: "project-4",
    title: "Soil Aeration & Rotary Tilling",
    category: "tilling",
    categoryLabel: "Tilling & Ground Preparation",
    description: "Soil conditioning and mechanical tilling to prepare beds for direct seed and turf installation.",
    aspectRatio: "4:3",
    isRepresentative: true
  },
  {
    id: "project-5",
    title: "Property Boundary Timber Fencing",
    category: "fencing",
    categoryLabel: "Fencing",
    description: "Clean horizontal slat fencing installed along the perimeter for neat seclusion and clear demarcation.",
    aspectRatio: "16:9",
    isRepresentative: true
  },
  {
    id: "project-6",
    title: "Outdoor Perimeter Renovation",
    category: "renovation",
    categoryLabel: "Renovation Services",
    description: "Site revitalization combining ground leveling, border restoration, and perimeter finish.",
    aspectRatio: "4:3",
    isRepresentative: true
  }
];

export const WHY_CHOOSE_US = [
  {
    title: "Range of Outdoor Service Options",
    description: "From routine lawn maintenance to complete fencing and ground preparation, handle multiple outdoor tasks through one reliable contact."
  },
  {
    title: "Clear Communication on Project Scope",
    description: "Direct discussions with Khushkaran ensure project requirements, timing, and expectations are understood before work begins."
  },
  {
    title: "Straightforward Enquiry Process",
    description: "No confusing automated forms or delayed callbacks. Call or message directly at 0484914973 to discuss your property needs."
  },
  {
    title: "Practical, Needs-Based Solutions",
    description: "Recommendations tailored to the realistic requirements of your land, yard layout, and budget."
  }
];
