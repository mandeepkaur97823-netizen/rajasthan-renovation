import React, { useState } from 'react';
import { Phone, MessageSquare, Copy, Check, AlertCircle } from 'lucide-react';
import { SERVICES_DATA, business } from '../config/business';

interface QuoteSectionProps {
  preselectedService?: string;
}

export const QuoteSection: React.FC<QuoteSectionProps> = ({ preselectedService }) => {
  const [name, setName] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [selectedService, setSelectedService] = useState(preselectedService || SERVICES_DATA[0].title);
  const [projectDescription, setProjectDescription] = useState('');
  const [copied, setCopied] = useState(false);
  const [showSummary, setShowSummary] = useState(false);

  // Sync if preselectedService changes
  React.useEffect(() => {
    if (preselectedService) {
      setSelectedService(preselectedService);
    }
  }, [preselectedService]);

  const compiledMessage = `Hello Khushkaran, my name is ${name || '[My Name]'}. I'm reaching out regarding ${selectedService}. Details: ${projectDescription || 'Please call to discuss the job.'} My contact: ${contactInfo || '[Phone]'}.`;

  const handleCopySummary = () => {
    navigator.clipboard.writeText(compiledMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrepareEnquiry = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSummary(true);
  };

  const smsUrl = `sms:${business.phoneDisplay}?body=${encodeURIComponent(compiledMessage)}`;

  return (
    <section id="quote" className="py-16 lg:py-24 bg-white border-b border-stone-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-10 sm:mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-[#346b3e] mb-2">
            Project Scoping
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#152e1b] tracking-tight">
            Let’s Discuss Your Project
          </h2>
          <p className="mt-3 text-stone-600 text-base sm:text-lg max-w-2xl mx-auto">
            Get in touch to discuss the service you need and the details of your project.
          </p>
        </div>

        {/* Form Container */}
        <div className="bg-[#faf8f5] rounded-3xl border border-stone-200 p-6 sm:p-10 shadow-sm">
          
          {/* Transparent Contact Notice */}
          <div className="mb-8 p-4 rounded-xl bg-amber-50/80 border border-amber-200/80 flex items-start gap-3 text-xs sm:text-sm text-amber-900">
            <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong>Direct Phone &amp; SMS Enquiry:</strong> Rajasthan Renovation and Landscaping Services operates through direct personal consultation with Khushkaran. Use the form below to organize your project notes, then call or message directly at{' '}
              <a href={business.phoneTelLink} className="underline font-bold text-amber-950">
                {business.phoneDisplay}
              </a>.
            </div>
          </div>

          <form onSubmit={handlePrepareEnquiry} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Name Field */}
              <div>
                <label htmlFor="customer-name" className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                  Your Name <span className="text-emerald-700">*</span>
                </label>
                <input
                  type="text"
                  id="customer-name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. David Smith"
                  className="w-full px-4 py-3 rounded-xl bg-white border border-stone-300 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-[#70b431] focus:border-transparent transition-all"
                />
              </div>

              {/* Phone or Email Field */}
              <div>
                <label htmlFor="contact-info" className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                  Your Phone or Email <span className="text-emerald-700">*</span>
                </label>
                <input
                  type="text"
                  id="contact-info"
                  required
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  placeholder="e.g. 0400 123 456 or name@example.com"
                  className="w-full px-4 py-3 rounded-xl bg-white border border-stone-300 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-[#70b431] focus:border-transparent transition-all"
                />
              </div>

            </div>

            {/* Service Required */}
            <div>
              <label htmlFor="service-select" className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                Service Required
              </label>
              <select
                id="service-select"
                value={selectedService}
                onChange={(e) => setSelectedService(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white border border-stone-300 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-[#70b431] focus:border-transparent transition-all"
              >
                {SERVICES_DATA.map((s) => (
                  <option key={s.id} value={s.title}>
                    {s.title}
                  </option>
                ))}
                <option value="Multiple Outdoor Services">Multiple / Combined Outdoor Services</option>
                <option value="General Outdoor Consultation">General Outdoor Consultation</option>
              </select>
            </div>

            {/* Project Description */}
            <div>
              <label htmlFor="project-desc" className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                Project Description
              </label>
              <textarea
                id="project-desc"
                rows={4}
                value={projectDescription}
                onChange={(e) => setProjectDescription(e.target.value)}
                placeholder="Briefly describe your yard size, terrain, specific grass or shrub removal needs, fence length, or renovation ideas..."
                className="w-full px-4 py-3 rounded-xl bg-white border border-stone-300 text-stone-900 text-sm focus:outline-hidden focus:ring-2 focus:ring-[#70b431] focus:border-transparent transition-all resize-y"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                type="submit"
                className="flex-1 py-3.5 px-6 rounded-xl bg-[#1b3b22] hover:bg-[#122817] text-white font-semibold text-sm shadow-sm transition-colors text-center"
              >
                Request a Quote / Prepare Direct Enquiry
              </button>
              
              <a
                href={business.phoneTelLink}
                className="inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-[#70b431] hover:bg-[#5ea024] text-white font-semibold text-sm shadow-xs transition-colors"
              >
                <Phone className="w-4 h-4" />
                <span>Call Khushkaran Directly</span>
              </a>
            </div>
          </form>

          {/* Form Output / Summary Box (Transparent Direct Route) */}
          {showSummary && (
            <div className="mt-8 pt-8 border-t border-stone-300 space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                  Your Project Enquiry Ready for Khushkaran
                </span>
                <span className="text-xs text-stone-500">Contact: 0484914973</span>
              </div>

              <div className="p-4 rounded-xl bg-white border border-stone-200 text-stone-800 text-sm font-mono whitespace-pre-wrap leading-relaxed shadow-2xs">
                {compiledMessage}
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <a
                  href={business.phoneTelLink}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#1b3b22] hover:bg-[#122817] text-white text-xs sm:text-sm font-semibold transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#8de042]" />
                  <span>Call 0484914973 Now</span>
                </a>

                <a
                  href={smsUrl}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs sm:text-sm font-semibold transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Send via SMS</span>
                </a>

                <button
                  type="button"
                  onClick={handleCopySummary}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-stone-300 bg-white hover:bg-stone-50 text-stone-700 text-xs sm:text-sm font-medium transition-colors"
                >
                  {copied ? <Check className="w-4 h-4 text-[#70b431]" /> : <Copy className="w-4 h-4 text-stone-500" />}
                  <span>{copied ? 'Summary Copied!' : 'Copy Summary'}</span>
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
