import React from 'react';
import { Layers, MessageSquare, PhoneCall, SlidersHorizontal } from 'lucide-react';
import { WHY_CHOOSE_US, business } from '../config/business';

export const WhyChooseUs: React.FC = () => {
  const icons = [
    <Layers key="layers" className="w-5 h-5 text-[#70b431]" />,
    <MessageSquare key="message" className="w-5 h-5 text-[#70b431]" />,
    <PhoneCall key="phone" className="w-5 h-5 text-[#70b431]" />,
    <SlidersHorizontal key="sliders" className="w-5 h-5 text-[#70b431]" />
  ];

  return (
    <section className="py-16 lg:py-24 bg-[#faf8f5] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12 lg:mb-16">
          <div className="text-xs font-bold uppercase tracking-wider text-[#346b3e] mb-2">
            Workmanship &amp; Reliability
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#152e1b] tracking-tight">
            A Practical Approach to Outdoor Improvements
          </h2>
          <p className="mt-3 text-stone-600 text-base leading-relaxed">
            Every project begins with understanding your specific yard conditions, site access, and project goals—giving you straightforward recommendations without unnecessary complexity.
          </p>
        </div>

        {/* 4 Verified Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_CHOOSE_US.map((item, index) => (
            <div
              key={item.title}
              className="p-6 bg-white rounded-2xl border border-stone-200 flex flex-col justify-between shadow-2xs hover:border-emerald-700/30 transition-colors"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#1b3b22] flex items-center justify-center mb-4">
                  {icons[index]}
                </div>
                <h3 className="text-base font-bold text-[#152e1b] leading-snug">
                  {item.title}
                </h3>
                <p className="mt-2 text-stone-600 text-sm leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-100 text-xs font-medium text-stone-400">
                Pillar 0{index + 1}
              </div>
            </div>
          ))}
        </div>

        {/* Direct Contact Banner */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-[#1b3b22] text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h3 className="text-lg sm:text-xl font-bold">Have a unique outdoor layout or specific job?</h3>
            <p className="mt-1 text-sm text-emerald-100/80">
              Speak directly with Khushkaran to review your property needs and discuss scheduling.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={business.phoneTelLink}
              className="px-5 py-3 rounded-xl bg-[#70b431] hover:bg-[#5ea024] text-white text-sm font-semibold transition-colors flex items-center gap-2"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call {business.phoneDisplay}</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
