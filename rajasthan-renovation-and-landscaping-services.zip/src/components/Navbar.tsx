import React, { useState } from 'react';
import { Phone, Menu, X } from 'lucide-react';
import { business } from '../config/business';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Services', href: '#services' },
    { label: 'Our Work', href: '#work' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#1b3b22]/95 backdrop-blur-md border-b border-[#2d5736] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          
          {/* Zone 1: Brand Wordmark (Single Text Element) */}
          <a
            href="#home"
            className="text-lg sm:text-xl font-bold tracking-tight text-white hover:text-[#99e052] transition-colors whitespace-nowrap shrink-0"
          >
            {business.name}
          </a>

          {/* Zone 2: 5 Concise Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-emerald-100/90">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action (Call Khushkaran) */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={business.phoneTelLink}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#70b431] hover:bg-[#5ea024] text-white text-sm font-semibold shadow-xs transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#8de042]"
            >
              <Phone className="w-4 h-4 text-white" />
              <span>Call Khushkaran</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex sm:hidden items-center gap-2">
            <a
              href={business.phoneTelLink}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#70b431] text-white text-xs font-semibold"
              aria-label="Call Khushkaran"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call</span>
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-emerald-100 hover:text-white hover:bg-emerald-900/60 focus:outline-hidden"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-[#2d5736] bg-[#17321d] px-4 pt-3 pb-5 space-y-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2.5 rounded-md text-base font-medium text-emerald-50 hover:bg-emerald-800/50"
            >
              {link.label}
            </a>
          ))}
          <div className="pt-3 border-t border-emerald-800/60 mt-2">
            <a
              href={business.phoneTelLink}
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-lg bg-[#70b431] text-white font-semibold text-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Call Khushkaran — {business.phoneDisplay}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
