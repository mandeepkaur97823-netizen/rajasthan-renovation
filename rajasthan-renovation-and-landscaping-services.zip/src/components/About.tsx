import React from 'react';
import { Phone, CheckCircle2 } from 'lucide-react';
import { business } from '../config/business';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-16 lg:py-24 bg-[#faf8f5] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-[#346b3e]">
              Service Overview
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#152e1b] tracking-tight leading-tight">
              About {business.name}
            </h2>

            <div className="space-y-4 text-stone-600 text-base leading-relaxed">
              <p>
                {business.name} provides a wide range of practical outdoor services, including regular lawn mowing, landscape design, tree and shrub removal, ground tilling, boundary fencing, and confirmed outdoor renovation work.
              </p>
              <p>
                Whether you need straightforward yard maintenance to keep your property neat, site preparation for fresh planting or turf, or sturdy perimeter fencing, we focus on clear communication and realistic project solutions.
              </p>
              <p>
                All project discussions, quotes, and job coordination are handled directly with Khushkaran, ensuring you have a dedicated, single point of contact from start to finish.
              </p>
            </div>

            {/* Core commitments */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2.5 text-sm font-medium text-stone-800">
                <CheckCircle2 className="w-4 h-4 text-[#70b431] shrink-0" />
                <span>Direct phone consultation</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm font-medium text-stone-800">
                <CheckCircle2 className="w-4 h-4 text-[#70b431] shrink-0" />
                <span>Job-specific project review</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm font-medium text-stone-800">
                <CheckCircle2 className="w-4 h-4 text-[#70b431] shrink-0" />
                <span>Transparent outdoor solutions</span>
              </div>
              <div className="flex items-center gap-2.5 text-sm font-medium text-stone-800">
                <CheckCircle2 className="w-4 h-4 text-[#70b431] shrink-0" />
                <span>Clean work site cleanup</span>
              </div>
            </div>

            <div className="pt-4">
              <a
                href={business.phoneTelLink}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#1b3b22] hover:bg-[#122817] text-white text-sm font-semibold transition-colors"
              >
                <Phone className="w-4 h-4 text-[#8de042]" />
                <span>Contact Khushkaran — {business.phoneDisplay}</span>
              </a>
            </div>
          </div>

          {/* Quick Business Card Card */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl border border-stone-200 p-8 shadow-xs space-y-6">
              <div className="border-b border-stone-100 pb-5">
                <div className="text-xs uppercase tracking-wider text-stone-400 font-semibold">
                  Business Information
                </div>
                <h3 className="mt-1 text-xl font-bold text-[#152e1b]">
                  {business.name}
                </h3>
              </div>

              <div className="space-y-4 text-sm">
                <div>
                  <span className="block text-xs font-semibold text-stone-400 uppercase">Primary Contact</span>
                  <span className="font-semibold text-stone-800 text-base">{business.contactName}</span>
                </div>

                <div>
                  <span className="block text-xs font-semibold text-stone-400 uppercase">Direct Phone</span>
                  <a
                    href={business.phoneTelLink}
                    className="font-mono font-bold text-lg text-[#1b3b22] hover:text-[#5ea024] transition-colors"
                  >
                    {business.phoneDisplay}
                  </a>
                </div>

                <div>
                  <span className="block text-xs font-semibold text-stone-400 uppercase">Primary Work Scopes</span>
                  <p className="text-stone-600 text-xs mt-1 leading-relaxed">
                    Lawn Mowing &amp; Trimming · Landscape Design · Tree &amp; Shrub Removal · Ground Tilling · Fencing · Renovation Work
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-100 text-xs text-emerald-900 leading-relaxed">
                  <strong>Direct Enquiry Policy:</strong> Every job is quoted individually based on property size, terrain, vegetation volume, and specific owner preferences.
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
