import React, { useState } from 'react';
import { Phone, Copy, Check, ArrowRight, UserCheck } from 'lucide-react';
import { business } from '../config/business';

export const ContactSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(business.phoneDisplay);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="contact" className="py-16 lg:py-24 bg-[#1b3b22] text-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-[#99e052] mb-2">
            Get in Touch
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Contact Us
          </h2>
          <p className="mt-3 text-emerald-100/90 text-base max-w-xl mx-auto">
            Speak directly with Khushkaran to arrange a site visit, discuss landscape ideas, or organize outdoor maintenance.
          </p>
        </div>

        {/* Contact Card */}
        <div className="bg-[#142e1b] rounded-3xl border border-[#2d5736] p-8 sm:p-12 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Left Column: Business & Person Identification */}
            <div className="md:col-span-7 space-y-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-700/50 text-xs font-medium text-[#99e052]">
                <UserCheck className="w-3.5 h-3.5" />
                <span>Primary Contact Person</span>
              </span>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                {business.name}
              </h3>

              <div className="pt-2 space-y-2 text-emerald-100">
                <div className="text-base sm:text-lg">
                  <span className="text-emerald-400 font-medium">Contact person: </span>
                  <span className="font-bold text-white">{business.contactName}</span>
                </div>
                <div className="text-base sm:text-lg">
                  <span className="text-emerald-400 font-medium">Phone: </span>
                  <a
                    href={business.phoneTelLink}
                    className="font-mono font-bold text-xl sm:text-2xl text-[#8de042] hover:underline"
                  >
                    {business.phoneDisplay}
                  </a>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-emerald-200/80 leading-relaxed pt-2">
                Available by phone to discuss lawn mowing, landscape design, tree and shrub removal, ground tilling, boundary fencing, and confirmed renovation work.
              </p>
            </div>

            {/* Right Column: Interactive Contact Action Cluster */}
            <div className="md:col-span-5 flex flex-col gap-3">
              {/* Button 1: Call Now */}
              <a
                href={business.phoneTelLink}
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl bg-[#70b431] hover:bg-[#5ea024] text-white font-bold text-base shadow-md transition-all hover:scale-[1.01]"
              >
                <Phone className="w-5 h-5 text-white" />
                <span>Call Now — {business.phoneDisplay}</span>
              </a>

              {/* Button 2: Copy Phone Number */}
              <button
                type="button"
                onClick={handleCopyPhone}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-100 font-semibold text-sm transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-[#8de042]" /> : <Copy className="w-4 h-4 text-emerald-300" />}
                <span>{copied ? 'Phone Number Copied!' : 'Copy Phone Number'}</span>
              </button>

              {/* Button 3: Request a Quote */}
              <a
                href="#quote"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-semibold text-sm transition-colors"
              >
                <span>Request a Quote</span>
                <ArrowRight className="w-4 h-4 text-emerald-300" />
              </a>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
