import React from 'react';
import { Phone, Grid, MessageSquare } from 'lucide-react';
import { business } from '../config/business';

export const MobileStickyBar: React.FC = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 sm:hidden bg-[#142918]/95 backdrop-blur-md border-t border-[#2d5736] px-3 py-2 text-white">
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        
        {/* Services */}
        <a
          href="#services"
          className="flex flex-col items-center justify-center py-1 text-emerald-100 hover:text-white transition-colors"
        >
          <Grid className="w-4 h-4 mb-0.5 text-emerald-300" />
          <span className="font-medium text-[11px]">Services</span>
        </a>

        {/* Primary Call Action */}
        <a
          href={business.phoneTelLink}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#70b431] text-white font-bold text-xs shadow-md"
        >
          <Phone className="w-3.5 h-3.5 fill-white text-white" />
          <span>Call Now</span>
        </a>

        {/* Quote */}
        <a
          href="#quote"
          className="flex flex-col items-center justify-center py-1 text-emerald-100 hover:text-white transition-colors"
        >
          <MessageSquare className="w-4 h-4 mb-0.5 text-emerald-300" />
          <span className="font-medium text-[11px]">Quote</span>
        </a>

      </div>
    </div>
  );
};
