import React, { useState } from 'react';
import { Maximize2, X, Phone, Info } from 'lucide-react';
import { REPRESENTATIVE_GALLERY, GalleryProject, business } from '../config/business';
import { RepresentativeVisual } from './RepresentativeVisual';

export const Gallery: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeModalProject, setActiveModalProject] = useState<GalleryProject | null>(null);

  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'lawn', label: 'Lawn Maintenance' },
    { id: 'design', label: 'Landscape Design' },
    { id: 'trees', label: 'Tree & Shrub Work' },
    { id: 'fencing', label: 'Fencing' },
    { id: 'tilling', label: 'Ground Prep' },
    { id: 'renovation', label: 'Renovation' },
  ];

  const filteredProjects = activeCategory === 'all'
    ? REPRESENTATIVE_GALLERY
    : REPRESENTATIVE_GALLERY.filter((p) => p.category === activeCategory);

  return (
    <section id="work" className="py-16 lg:py-24 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-10">
          <div className="text-xs font-bold uppercase tracking-wider text-[#346b3e] mb-2">
            Visual Portfolio
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#152e1b] tracking-tight">
            Outdoor Spaces &amp; Landscaping Projects
          </h2>
          <p className="mt-3 text-stone-600 text-base">
            Explore typical scopes of work across lawn upkeep, garden beds, perimeter fencing, and land tilling.
          </p>

          {/* Transparent Notice */}
          <div className="mt-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-stone-100 border border-stone-200 text-xs text-stone-600">
            <Info className="w-3.5 h-3.5 text-stone-500" />
            <span>Representative visuals shown while real customer project photography is being uploaded.</span>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-[#1b3b22] text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group bg-[#faf8f5] rounded-2xl border border-stone-200 overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              {/* Visual Container with Lightbox Trigger */}
              <div className="relative aspect-4/3 w-full bg-stone-900 overflow-hidden">
                <RepresentativeVisual
                  type={project.category}
                  className="w-full h-full rounded-none border-none shadow-none"
                  badge={`Representative: ${project.categoryLabel}`}
                />
                
                <button
                  onClick={() => setActiveModalProject(project)}
                  className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white font-medium text-xs backdrop-blur-xs"
                  aria-label={`Inspect ${project.title}`}
                >
                  <Maximize2 className="w-4 h-4" />
                  <span>Inspect Project Scope</span>
                </button>
              </div>

              {/* Information */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
                    {project.categoryLabel}
                  </div>
                  <h3 className="text-lg font-bold text-[#152e1b] group-hover:text-emerald-800 transition-colors">
                    {project.title}
                  </h3>
                  <p className="mt-2 text-stone-600 text-xs sm:text-sm leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-200/80 flex items-center justify-between text-xs">
                  <span className="text-stone-400">Standard Scope</span>
                  <button
                    onClick={() => setActiveModalProject(project)}
                    className="font-semibold text-[#1b3b22] hover:text-[#5ea024] transition-colors"
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-2xl bg-[#faf8f5] rounded-2xl overflow-hidden shadow-2xl border border-stone-700">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-stone-200 bg-white">
              <div>
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                  {activeModalProject.categoryLabel}
                </span>
                <h3 className="text-lg font-bold text-[#152e1b]">
                  {activeModalProject.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalProject(null)}
                className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-100"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Visual */}
            <div className="relative aspect-16/10 w-full bg-stone-900">
              <RepresentativeVisual
                type={activeModalProject.category}
                className="w-full h-full rounded-none border-none"
                badge="Representative Visualization"
              />
            </div>

            {/* Modal Details */}
            <div className="p-6 bg-white space-y-4">
              <p className="text-sm text-stone-600 leading-relaxed">
                {activeModalProject.description}
              </p>

              <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-600">
                <strong>Project Consultation:</strong> To schedule this type of work or discuss site-specific requirements, contact Khushkaran directly by phone.
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <a
                  href={business.phoneTelLink}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#1b3b22] hover:bg-[#122817] text-white text-sm font-semibold transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#8de042]" />
                  <span>Call Khushkaran — {business.phoneDisplay}</span>
                </a>
                <button
                  onClick={() => setActiveModalProject(null)}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-stone-300 text-stone-700 text-sm font-medium hover:bg-stone-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
