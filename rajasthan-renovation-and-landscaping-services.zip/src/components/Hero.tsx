import React from 'react';
import { Phone, ArrowDownRight, Compass, ShieldCheck } from 'lucide-react';
import { business } from '../config/business';
import { RepresentativeVisual } from './RepresentativeVisual';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="relative bg-[#faf8f5] pt-8 pb-16 lg:pt-16 lg:pb-24 overflow-hidden border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Split Screen Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Headings & Direct Actions */}
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            
            {/* Clear Service Kicker */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#2e5d37]">
              <span>Direct Outdoor Solutions</span>
              <span aria-hidden="true">·</span>
              <span>Khushkaran</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#152e1b] tracking-tight leading-[1.15] text-balance">
                Transform Your Outdoor Space
              </h1>
              <p className="text-lg sm:text-xl font-medium text-[#3b6d46]">
                Landscaping, Lawn Care &amp; Renovation Services
              </p>
            </div>

            {/* Description */}
            <p className="text-base text-stone-600 leading-relaxed max-w-xl">
              From lawn mowing and garden maintenance to landscape design and fencing, explore practical services to help improve your outdoor space.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <a
                href={business.phoneTelLink}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#1b3b22] hover:bg-[#122817] text-white font-semibold text-base shadow-sm transition-all hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1b3b22]"
              >
                <Phone className="w-5 h-5 text-[#8de042]" />
                <span>Call Now — {business.phoneDisplay}</span>
              </a>

              <a
                href="#services"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 font-semibold text-base transition-colors"
              >
                <span>Explore Our Services</span>
                <ArrowDownRight className="w-4 h-4 text-stone-500" />
              </a>
            </div>

            {/* Practical Verification Marker */}
            <div className="pt-4 border-t border-stone-200/80 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-stone-500">
              <div className="flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-[#447e38]" />
                <span>Project-specific site quotes</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#447e38]" />
                <span>Direct consultation with Khushkaran</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Showcase */}
          <div className="lg:col-span-6">
            <div className="relative">
              {/* Decorative clean offset frame */}
              <div className="absolute -inset-2 bg-gradient-to-tr from-[#70b431]/20 to-[#1b3b22]/10 rounded-3xl filter blur-md -z-10" />
              <RepresentativeVisual
                type="hero"
                className="w-full aspect-16/10 rounded-2xl shadow-xl"
                badge="Representative Landscape Design & Lawn Care Visual"
              />

              {/* Direct Call Banner below image */}
              <div className="mt-4 p-4 rounded-xl bg-[#1b3b22] text-white flex items-center justify-between gap-4 shadow-sm">
                <div>
                  <div className="text-xs text-emerald-200 font-medium">Ready to discuss your project?</div>
                  <div className="text-sm sm:text-base font-bold text-white">Contact Khushkaran directly</div>
                </div>
                <a
                  href={business.phoneTelLink}
                  className="px-4 py-2 rounded-lg bg-[#70b431] hover:bg-[#5ea024] text-white text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors"
                >
                  {business.phoneDisplay}
                </a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
