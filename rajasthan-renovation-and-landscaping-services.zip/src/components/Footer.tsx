import React from 'react';
import { Phone } from 'lucide-react';
import { SERVICES_DATA, business } from '../config/business';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#122316] text-stone-400 border-t border-[#1e3b25] pt-12 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 pb-10 border-b border-[#213f28]">
          
          {/* Brand & Description */}
          <div className="md:col-span-5 space-y-3">
            <span className="text-lg font-bold text-white block">
              {business.name}
            </span>
            <p className="text-sm text-stone-400 leading-relaxed max-w-sm">
              Lawn mowing, landscape design, tree and shrub removal, ground tilling, fencing, and outdoor renovation services.
            </p>
          </div>

          {/* Services Navigation */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Services
            </div>
            <ul className="space-y-2 text-xs sm:text-sm">
              {SERVICES_DATA.map((service) => (
                <li key={service.id}>
                  <a
                    href="#services"
                    className="hover:text-white transition-colors"
                  >
                    {service.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Direct Contact
            </div>
            <div className="text-sm space-y-1">
              <div className="text-white font-medium">Contact: {business.contactName}</div>
              <a
                href={business.phoneTelLink}
                className="inline-flex items-center gap-1.5 font-mono text-base font-bold text-[#8de042] hover:underline"
              >
                <Phone className="w-3.5 h-3.5 text-[#8de042]" />
                <span>{business.phoneDisplay}</span>
              </a>
            </div>
            <p className="text-xs text-stone-500">
              Call directly for project discussions and bookings.
            </p>
          </div>

        </div>

        {/* Bottom Line Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-4">
          <div>
            &copy; {currentYear} {business.name}. All rights reserved.
          </div>
          <div className="text-stone-500">
            Dedicated Workmanship &amp; Practical Outdoor Solutions
          </div>
        </div>
      </div>
    </footer>
  );
};
