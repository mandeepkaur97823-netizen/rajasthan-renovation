import React from 'react';
import { Phone, ArrowRight, Check } from 'lucide-react';
import { SERVICES_DATA, business } from '../config/business';
import { RepresentativeVisual } from './RepresentativeVisual';

interface ServicesProps {
  onSelectServiceForEnquiry?: (serviceTitle: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onSelectServiceForEnquiry }) => {
  return (
    <section id="services" className="py-16 lg:py-24 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-12 sm:mb-16">
          <div className="text-xs font-bold uppercase tracking-wider text-[#346b3e] mb-2">
            Outdoor Transformation &amp; Care
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#152e1b] tracking-tight">
            Our Services
          </h2>
          <p className="mt-3 text-stone-600 text-base sm:text-lg">
            Practical landscaping, maintenance, and outdoor solutions delivered with dedicated workmanship.
          </p>
        </div>

        {/* 6 Visual Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES_DATA.map((service) => (
            <article
              key={service.id}
              className="group flex flex-col bg-[#faf8f5] rounded-2xl border border-stone-200 overflow-hidden transition-all duration-200 hover:shadow-lg hover:border-emerald-700/40"
            >
              {/* Service Visual */}
              <div className="relative aspect-4/3 w-full bg-stone-100 overflow-hidden">
                <RepresentativeVisual
                  type={service.category}
                  className="w-full h-full rounded-none border-none shadow-none"
                  badge={`Representative: ${service.tag}`}
                />
              </div>

              {/* Service Card Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  {/* Service Number & Category Header */}
                  <div className="flex items-center justify-between text-xs font-semibold text-stone-500 mb-2">
                    <span className="font-mono text-emerald-800 font-bold">{service.number}</span>
                    <span>{service.tag}</span>
                  </div>

                  <h3 className="text-xl font-bold text-[#152e1b] group-hover:text-emerald-800 transition-colors">
                    {service.title}
                  </h3>

                  <p className="mt-2.5 text-stone-600 text-sm leading-relaxed">
                    {service.shortDesc}
                  </p>

                  <p className="mt-2 text-stone-500 text-xs leading-relaxed">
                    {service.fullDesc}
                  </p>

                  {/* Feature Checkpoints */}
                  <ul className="mt-4 space-y-2 border-t border-stone-200/80 pt-3">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-stone-700">
                        <Check className="w-3.5 h-3.5 text-[#5ea024] shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Enquiry Action Button */}
                <div className="mt-6 pt-4 border-t border-stone-200 flex items-center justify-between gap-3">
                  <a
                    href="#quote"
                    onClick={() => {
                      if (onSelectServiceForEnquiry) {
                        onSelectServiceForEnquiry(service.title);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1b3b22] hover:text-[#5ea024] transition-colors"
                  >
                    <span>Enquire Now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>

                  <a
                    href={business.phoneTelLink}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#eef7e8] hover:bg-[#d9efcb] text-[#24522c] text-xs font-semibold transition-colors"
                    aria-label={`Call Khushkaran about ${service.title}`}
                  >
                    <Phone className="w-3 h-3 text-[#5ea024]" />
                    <span>Call Khushkaran</span>
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>

      </div>
    </section>
  );
};
